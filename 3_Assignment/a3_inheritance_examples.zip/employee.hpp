#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include "person.hpp"
using namespace std;

class Employee : public Person {
    string eType;
    int salary;

public:
    Employee();
    Employee(string fName, string lName, int nAge, string nEType, int nSalary);
    ~Employee();

    Employee(const Employee& newEmp);
    Employee& operator =(const Employee& newEmp);

    string getEType() const;
    int getSalary() const;

    void setEType(string newtype);
    void setSalary(int newSalary);

    void printDetails();
    void printDetailsNoHeader();
};

#endif // EMPLOYEE_H
