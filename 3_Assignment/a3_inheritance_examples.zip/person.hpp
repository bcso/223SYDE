#ifndef PERSON_H
#define PERSON_H

#include <string>
using namespace std;

class Person {
protected:
    string firstName;
    string lastName;
    int age;

public:
    Person();
    Person(string firstName, string lastName, int age);
    ~Person();

    string getFirstName() const;
    string getLastName() const;
    int getAge() const;

    void setFirstName(string name);
    void setLastName(string name);
    void setAge(int age);

    void printDetails();
    void printDetailsNoHeader();
    void printHeaderData();
};

#endif // PERSON_H
