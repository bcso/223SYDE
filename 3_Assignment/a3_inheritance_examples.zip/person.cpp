#include <iostream>
#include <string>

#include "person.hpp"
using namespace std;

/*
int main() {
    Person myData("Smith");
    testClassConst(myData);
    myData.printDetails();

    myData.printHeaderData();

    myData = Person("Max", "Jones", 35);
    myData.printDetails();

    return 0;
}
*/

Person::Person(string fName, string lName, int nAge) {
    firstName = fName;
    lastName = lName;
    age = nAge;
}

Person::~Person() {
    cout << "\nDestructor called on Person: ";
    printDetailsNoHeader();
}

void Person::printHeaderData() {
    cout << "Person Details: ";
}

void Person::printDetailsNoHeader() {
    cout << firstName << ", " << lastName;
    cout << ", " << age << endl;
}

void Person::printDetails() {
    Person::printHeaderData();
    cout << firstName << ", " << lastName;
    cout << ", " << age << endl;
}

string Person::getFirstName() const {
    return firstName;
}

string Person::getLastName() const {
    return lastName;
}

int Person::getAge() const {
    return age;
}

void Person::setFirstName(string newName) {
    firstName = newName;
}

void Person::setLastName(string newName) {
    lastName = newName;
}

void Person::setAge(int newAge) {
    age = newAge;
}
