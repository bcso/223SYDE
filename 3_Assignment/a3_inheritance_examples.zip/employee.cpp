#include <iostream>
#include <string>
#include "employee.hpp"
using namespace std;

int main() {
    Employee emp("John", "Smith", 35, "Salaried", 50000);

    cout << "\nEmployee's printDetails() called" << endl;
    emp.printDetails();  // Employee's printDetails() called

    cout << "\nPerson's printDetails() called" << endl;
    emp.Person::printDetails(); // Person's printDetails() called

    Employee emp2("Max", "Johnson", 30, "Salaried", 45000);
    emp = emp2;
    cout << "\nEmployee's printDetails() called" << endl;
    emp.printDetails();  // Employee's printDetails() called

    Employee emp3(emp);
    cout << "\nEmployee's printDetails() called" << endl;
    emp3.printDetails();  // Employee's printDetails() called

    Person *p = dynamic_cast<Person*>(&emp); // Example of safe upcasting
    if (p) {
        cout << "\nPerson's printDetails() called" << endl;
        p->printDetails();
    }


/*  //DOWNCASTING EXAMPLE 1 START
    // Unsafe downcasting using static_cast
    Person *person = new Person("John", "Smithson", 25);
    Employee *e = static_cast<Employee*>(person); // VERY DANGEROUS - see the results for yourself

    // Does not work with dynamic_cast unless Person is polymorphic
    // That is, one should NOT downcast to derived types since derived types could have additional members

    if (e) {
        cout << "Employee's printDetails() called" << endl;
        e->printDetails(); // results in a segmentation fault
    }
    delete person;

*/

/*  // DOWNCASTING EXAMPLE 2 START
    // Unsafe downcasting using pointers
    Person *person = new Person("John", "Smithson", 25);
    Employee *e = (Employee*) person; // VERY DANGEROUS - see the results for yourself
    // That is, one should NOT downcast to derived types since derived types could have additional members
    if (e) {
        cout << "Employee's printDetails() called" << endl;
        e->printDetails(); // results in a segmentation fault
    }
    delete person;
*/

    return 0;
}

Employee::Employee(string fName, string lName, int nAge, string nEType, int nSalary) : 
	Person(fName, lName, nAge), eType(nEType), salary(nSalary) {
}

Employee::~Employee() {
    cout << "\nDestructor called on Employee: ";
    printDetailsNoHeader();
}

Employee::Employee(const Employee& nEmp) : Person(nEmp), eType(nEmp.eType), salary(nEmp.salary) {}

Employee& Employee::operator =(const Employee& nEmp) {
    Person::operator =(nEmp);
    eType = nEmp.eType;
    salary = nEmp.salary;
    return *this;
}

string Employee::getEType() const {
    return eType;
}

int Employee::getSalary() const {
    return salary;
}

void Employee::setEType(string newEType) {
    eType = newEType;
}

void Employee::setSalary(int newSalary) {
    salary = newSalary;
}

void Employee::printDetails() {
    Person::printDetails();
    cout << eType << ", " << salary << endl;
}

void Employee::printDetailsNoHeader() {
    Person::printDetailsNoHeader();
    cout << eType << ", " << salary << endl;
}
